// Function to scrolll to each section after clicking on menu
(function($) {
    $(function() {
        
        // scroll to sections
        $("[class^='scroll-section']").click(function(e) {
            e.preventDefault();

            const sectionNumber = this.className.match(/scroll-section(\d)/)?.[1];
            const sectionMap = {
                1: { selector: ".about", offset: 40 },
                2: { selector: ".education", offset: 40 },
                3: { selector: ".skills", offset: 40 },
                4: { selector: ".experience", offset: 40 },
                5: { selector: ".awards", offset: 40 },
                6: { selector: ".portfolio", offset: 40 },
                7: { selector: ".contact", offset: 40 },
            };

            const section = sectionMap[sectionNumber];
            if (section) {
                const scrollTo = $(section.selector).offset().top - section.offset;
                $("html, body").animate({ scrollTop: scrollTo }, 500);
            }
        });

        // scroll-up button
        $(".scroll-up").click(function(e){
            e.preventDefault();
            $("html, body").animate({scrollTop: 0}, 500);
        });
});

})(jQuery);