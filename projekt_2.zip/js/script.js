// main javascript script
document.addEventListener('DOMContentLoaded', () => {
    const menu = document.querySelector('header .menu');
    const moreButton = document.querySelector('.more');
    const menuLinks = document.querySelectorAll('header .menu ul li a');
    const scrollUp = document.querySelector('.scroll-up'); // přidáno

    const sections = [
        { selector: '.about', nav: 'n1' },
        { selector: '.education', nav: 'n2' },
        { selector: '.skills', nav: 'n4' },
        { selector: '.experience', nav: 'n3' },
        { selector: '.awards', nav: 'n5' },
        { selector: '.portfolio', nav: 'n6' },
        { selector: '.contact', nav: 'n7' }
    ];

    // Roll out / Roll in the menu
    moreButton?.addEventListener('click', () => {
        const state = menu.getAttribute('data-state');
        menu.setAttribute('data-state', state === 'rolled-out' ? 'rolled-in' : 'rolled-out');
    });

    // Roll back in the menu after clicking on section
    menuLinks.forEach(link =>
        link.addEventListener('click', () => {
            if (menu.getAttribute('data-state') === 'rolled-out') {
                menu.setAttribute('data-state', 'rolled-in');
            }
        })
    );

    // change current scrolled section
    const items = document.querySelectorAll('header .menu ul li');
    const updateMenuHighlight = () => {
        let closest = null, closestOffset = Infinity;

        sections.forEach(({ selector, nav }) => {
            const el = document.querySelector(selector);
            if (el) {
                const rect = el.getBoundingClientRect();
                const offset = Math.abs(rect.top);
                if (offset < closestOffset && rect.top <= window.innerHeight) {
                    closest = nav;
                    closestOffset = offset;
                }
            }
        });

        items.forEach(item => item.classList.remove('scrolled'));
        if (closest) {
            document.querySelector(`header .menu ul li.${closest}`)?.classList.add('scrolled');
        }
    };


    // check if the website is scrolled at top
    const updateScrollTopClass = () => {
        if (!scrollUp) return;
        if (window.scrollY <= 40) {
            document.documentElement.classList.add('at-top');
        } else {
            document.documentElement.classList.remove('at-top');

        }
    };

    window.addEventListener('scroll', () => {
        updateMenuHighlight();
        updateScrollTopClass();
    });

    // Initial check on load
    updateMenuHighlight();
    updateScrollTopClass();
});
