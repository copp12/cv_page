// Function to handle contact form after submit
function contact_submit() {
    let form = document.querySelector(".contact-form");

    if (form) {
        form.classList.toggle("open");

        setTimeout(() => {
            document.querySelectorAll("input[type='submit']")?.forEach((btn) => btn.disabled = true);
        }, 0);

        setTimeout(() => {
            form.classList.toggle("open");
            document.querySelectorAll("input[type='submit']")?.forEach((btn) => btn.disabled = false);
        }, 3000);
    }
}